#include <stdio.h>

#include "ApplicationLayer.h"
#include "tools.h"

int receiver(int fd, ApplicationLayer Alr);