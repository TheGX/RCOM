 
extern int timeout;
extern int n_timeout;
void handler();

void setAlarm();

void stopAlarm();